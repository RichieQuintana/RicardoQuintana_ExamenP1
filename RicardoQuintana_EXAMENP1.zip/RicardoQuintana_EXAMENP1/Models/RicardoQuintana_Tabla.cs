﻿namespace RicardoQuintana_ExamenP1.Models
{
    public class RicardoQuintana_Tabla
    {
        public int id { get; set; }
        public string name { get; set; }

        public string description { get; set; }
        DateTime fechactual = new DateTime(1, 1, 2020);
    }
}
